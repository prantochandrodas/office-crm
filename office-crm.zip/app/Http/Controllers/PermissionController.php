<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PermissionController extends Controller
{
    //  public function index()
    // {
    //     if (auth()->check()) {
    //         if (auth()->user()->can('permission')) {
    //             $permissions = Permission::all();
    //             return view('RolesPermission.Permission.index', compact('permissions'));
    //         } else {
    //             return redirect()->back()->with('error', 'You do not have permission to view permission page.');
    //         }
    //     } else {
    //         return redirect()->route('login')->with('error', 'You need to login first.');
    //     }
    // }
    //  public function index()
    // {
    //     $permissions = Permission::all();
    //     return view('RolesPermission.Permission.index', compact('permissions'));
       
    // }
}
