<?php
function generalSetting(){
    return App\Models\Application::first();
}
